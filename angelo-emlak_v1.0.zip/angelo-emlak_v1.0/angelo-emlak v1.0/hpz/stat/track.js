<!--

// SCRIPTLOCATION -- CHANGE THE VALUE BELOW TO A URL WHERE TRACK.ASP IS INSTALLED
// MAKE SURE YOU CHANGE THIS URL OF THE IMAGE SRC AT THE BOTTOM AS WELL
var scriptlocation = "/metatraffic/track.asp";

// CREATE VARIABLE WITH PAGE DATA IN IT
var pagedata = 'r=' + escape(document.referrer) + '&t=2&s=' + window.screen.width + 'x' + window.screen.height + '&z=' + Math.random() 

document.write ('<img height=1 width=1 ');
document.write ('src="' + scriptlocation + '?' + pagedata + '">');

//-->