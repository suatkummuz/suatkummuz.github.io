	var mode = "WYSIWYG";
	var subdirectory = "ak_images/";
	var txtareaname = null;
	var buttonlist = Array(	'FontName',
							'FontSize',
							'SelectAll',
							'Delete',
							'Cut',
							'Copy',
							'Paste',
							'SaveAs',
							'Print',
							'Separator',
							'Bold',
							'Italic',
							'Underline',
							'Strikethrough',
							'Separator',
							'JustifyLeft',
							'JustifyCenter',
							'JustifyRight',
							'JustifyFull',
							'Separator',
							'InsertOrderedList',
							'InsertUnorderedList',
							'Outdent',
							'Indent',
							'Separator',
							'SuperScript',
							'SubScript',
							'Separator',
							'InsertHorizontalRule',
							'CreateLink',
							'Unlink',
							'Image',
							'Table',
							'SpecialChars',
							'Separator',
							'Forecolor',
							'Backcolor',
							'Separator',
							'Date',
							'ChangeMode',
							'Separator',							
							'Help'
					);	
					
	var menuButtons = {
						//	 button id					     	images								help text			  click&hold  statuscheck Disable(html mode)						          
						"SelectAll": 						['mn_selectall.gif', 					'T�m�n� Se�', 			'0',	'0',		'0'],
						"Delete":							['mn_delete.gif', 						'Sil', 					'0',	'0',		'0'],
						"Cut":								['mn_cut.gif',							'Kes', 					'0',	'0',		'0'],
						"Copy":								['mn_copy.gif',							'Kopyala', 				'0',	'0',		'0'],
						"Paste":							['mn_paste.gif',						'Yap��t�r', 			'0',	'0',		'0'],
						"SaveAs":							['mn_saveas.gif',						'Farkl� Kaydet', 		'0',	'0',		'0'],
						"Print":							['mn_print.gif',						'Yazd�r', 				'0',	'0',		'0'],
						"Bold":								['mn_bold.gif',							'Kal�n', 				'1',	'1',		'1'],
						"Italic":							['mn_italic.gif',						'�talik', 				'1',	'1',		'1'],
						"Underline":						['mn_underline.gif',					'Alt� �izili', 			'1',	'1',		'1'],
						"Strikethrough":					['mn_strikethrough.gif',				'�zeri �izili', 		'1',	'1',		'1'],
						"JustifyLeft":						['mn_justifyleft.gif',					'Sola Yasla', 			'1',	'1',		'1'],
						"JustifyCenter":					['mn_justifycenter.gif',				'Ortala', 				'1',	'1',		'1'],
						"JustifyRight":						['mn_justifyright.gif',					'Sa�a Yasla', 			'1',	'1',		'1'],
						"JustifyFull":						['mn_justifyfull.gif',					'T�m�ne Yasla', 		'1',	'1',		'1'],
						"InsertOrderedList":				['mn_insertorderedlist.gif',			'Numaral� Liste', 		'1',	'1',		'1'],
						"InsertUnorderedList":				['mn_insertunorderedlist.gif',			'�mli Liste', 			'1',	'1',		'1'],
						"Outdent":							['mn_outindent.gif',					'Sola Al',	 			'0',	'0',		'1'],
						"Indent":							['mn_indent.gif',						'Sa�a Al', 				'0',	'0',		'1'],
						"SuperScript":						['mn_superscript.gif',					'�st Simge', 			'0',	'1',		'1'],
						"SubScript":						['mn_subscript.gif',					'Alt Simge', 			'0',	'1',		'1'],
						"InsertHorizontalRule":				['mn_inserthorizontalrule.gif',			'Yatay �izgi Ekle', 	'0',	'0',		'1'],
						"CreateLink":						['mn_createlink.gif',					'Ba�lant� Yap', 		'0',	'0',		'1'],
						"Unlink":							['mn_unlink.gif',						'Ba�lant�y� Kald�r',	'0',	'0',		'1'],
						"Image":							['mn_image.gif',						'Resim Ekle', 			'0',	'0',		'1'],
						"Table":							['mn_table.gif',						'Tablo Ekle', 			'0',	'0',		'1'],
						"SpecialChars":						['mn_specialchars.gif',					'�zel Karakterler', 	'0',	'0',		'1'],
						"Forecolor":						['mn_forecolor.gif',					'Metin Rengi', 			'0',	'0',		'1'],
						"Backcolor":						['mn_backcolor.gif',					'Arkaplan Rengi', 		'0',	'0',		'1'],
						"Date":								['mn_date.gif',							'Tarih Ekle',			'0',	'0',		'1'],
						"ChangeMode":						['mn_changemode.gif',					'Mod De�i�tir', 		'1',	'0',		'0'],
						"Help":								['mn_help.gif',							'Yard�m', 				'0',	'0',		'0']
						};
	
	document.writeln('<style type="text/css">');
	document.writeln('.btn     		{ width: 22px; height: 22px; border: 0px solid buttonface; margin: 0; padding: 0; background-color: #dadada};');
	document.writeln('.btnOver 		{ width: 22px; height: 22px; border: 1px outset; background-color: #D8D8D8D};');
	document.writeln('.btnDown 		{ width: 22px; height: 22px; border: 1px inset; background-color: buttonhighlight};');
	document.writeln('.btnDisabled  { width: 22px; height: 22px; border: 1px solid buttonface; filter: alpha(opacity=30)};');
	document.writeln('.tablebg 		{ border: 1px solid buttonface; margin: 0; padding: 0; background-color: #dadada};');
	document.writeln('.optfont		{ background-color: #ffffff; color: #000000; font-family: Verdana; font-size: 10px};');
	document.writeln('</style>');


	function ak_wysiwyg_generator(width, height, txtarea_name, bnconfig) 
	{ 
		if (!width) {width = 452;};
		if (!height) {height = 200;};
		var iebrowser_version = parseFloat(navigator.appVersion.split("MSIE")[1]);
		if (navigator.userAgent.indexOf('Mac')>=0 || navigator.userAgent.indexOf('Windows CE')>=0 || navigator.userAgent.indexOf('Opera')>=0) { iebrowser_version = 0;}
		if (iebrowser_version >= 5.5) {
			//Begin of WYSIWYG editor
			if (txtarea_name) {
				document.getElementById(txtarea_name).style.display="none";
				txtareaname = txtarea_name; 
			}
			if (bnconfig) {buttonlist = bnconfig;}
			if (AK_editor_url) {subdirectory = AK_editor_url + subdirectory}		
			
			document.writeln('<table border="0" width="100%" class="tablebg"><tr><td width=' + width + ' valign="top">');			
			for (var j=0; j<buttonlist.length;j++) {
				if (buttonlist[j] == 'Separator'){
					document.writeln('<span style="border-left:1px solid #666666; border-right:1px solid #CCCCCC; height: 16px; margin: 0 1 0 1"></span>');
				} else if (buttonlist[j] == 'FontName') {					
					document.writeln(' <select id="bn_ak_fontname" class="optfont" onchange="ak_fontname();">');
					document.writeln(' 	<option value="Arial">Arial</option>');
					document.writeln('	<option value="Courier New">Courier New</option>');
					document.writeln('	<option value="Georgia">Georgian</option>');
					document.writeln('	<option value="Tahoma">Tahoma</option>');
					document.writeln('	<option value="Times New Roman">Times New</option>');
					document.writeln('	<option value="Verdana" selected>Verdana</option>');
					document.writeln('	<option value="impact">Impact</option>');
					document.writeln('</select>');
				} else if (buttonlist[j] == 'FontSize') {
					document.writeln('<select id="bn_ak_fontsize" class="optfont" onchange="ak_fontsize();">');
					document.writeln(' 	<option value="1" selected> 8pt </option>');
					document.writeln('	<option value="2"> 10pt </option>');
					document.writeln('	<option value="3"> 12pt </option>');
					document.writeln(' 	<option value="4"> 14pt </option>');
					document.writeln('	<option value="5"> 18pt </option>');
					document.writeln('	<option value="6"> 24pt </option>');
					document.writeln('	<option value="7"> 36pt </option>');
					document.writeln('</select>');
				} else {
					if (menuButtons[buttonlist[j]][2]=='1') {
						document.writeln('<button id=\"bn_ak_' + buttonlist[j].toLowerCase()+ '\" onclick=\"m_click(this);ak_' +buttonlist[j].toLowerCase()+ '();" 	class="btn" onmouseover="m_over(this);" onmouseout="m_out(this);"><img src="' + subdirectory + menuButtons[buttonlist[j]][0] + '" alt="' + menuButtons[buttonlist[j]][1] + '" border="0"></button>');
					} else {
						document.writeln('<button id=\"bn_ak_' + buttonlist[j].toLowerCase()+ '\" onclick=\"ak_' +buttonlist[j].toLowerCase()+ '();" 	class="btn" onmouseover="m_over(this);" onmouseout="m_out(this);"><img src="' + subdirectory + menuButtons[buttonlist[j]][0] + '" alt="' + menuButtons[buttonlist[j]][1] + '" border="0"></button>');
					}
				}
			}
//			document.writeln('<button id="bn_ak_info" 			onclick="ak_info();" 										class="btn" onmouseover="m_over(this);" onmouseout="m_out(this);"><img src="'+subdirectory+'mn_info.gif" alt="About Us" border="0"></button>&nbsp;');
			document.writeln('</td></tr></table>');
			document.writeln('<iframe frameborder="0" style="border: 1px solid #416295" id="myEditor" width="' + width + '" height="' + height + '" src="'+subdirectory+'/blank.html"></iframe>');
			
			myEditor.document.designMode = 'On';
			
			if (txtareaname) {
				var command = "myEditor.document.body.innerHTML = document.getElementById(txtareaname).value;"
        		setTimeout(command,500);	
			}		
			
			frames['myEditor'].document.onkeyup = keyHandler;
			frames['myEditor'].document.onmouseup = keyHandler;
			document.keydown = externalkeyHandler;
			document.onmousedown = externalkeyHandler;
			
			//End of WYSIWYG editor
		} else if (!txtarea_name) {
			document.writeln('<textarea id="myEditor" cols="' + parseInt(width/8) + '" rows="' + parseInt(height/15) + '">*** Your browser must be IE5.0 or above to display the editor\'s controls ***</textarea>');		
		}		
	}
	 
	function ak_fontname() 
	{ 
		myEditor.focus();	
		var name = document.getElementById('bn_ak_fontname').value;
		myEditor.document.execCommand('FontName', false, name); 
	}
	
	function ak_fontsize() 
	{ 
		myEditor.focus();	
		var size = document.getElementById('bn_ak_fontsize').value;
		myEditor.document.execCommand('FontSize', false, size); 
	}
	
	function ak_bold() 
	{ 
		myEditor.focus();	
		myEditor.document.execCommand('Bold', false, null); 
	}
	
	function ak_italic() 
	{ 
		myEditor.focus();
		myEditor.document.execCommand('Italic', false, null); 
	}
	
	function ak_underline() 
	{ 
		myEditor.focus();
		myEditor.document.execCommand('Underline', false, null); 
	}
	function ak_strikethrough() 
	{ 
		myEditor.focus();
		myEditor.document.execCommand('StrikeThrough', false, null); 
	}

	function ak_createlink()
	{
		myEditor.focus();
		myEditor.document.execCommand('CreateLink', true, null); 
	}
	
	function ak_unlink()
	{
		myEditor.focus();
		myEditor.document.execCommand('Unlink', false, null); 
	}
		function ak_print()
	{
		myEditor.focus();
		myEditor.document.execCommand('Print', false, null); 
	}
	function ak_selectall()
	{
		myEditor.focus();
		myEditor.document.execCommand('SelectAll', false, null); 
	}
	
	function ak_delete()
	{
		myEditor.focus();
		myEditor.document.execCommand('Delete', false, null); 
	}	
	function ak_copy()
	{
		myEditor.focus();
		myEditor.document.execCommand('Copy', false, null); 
	}
	function ak_paste()
	{
		myEditor.focus();
		myEditor.document.execCommand('Paste', false, null); 
	}
	function ak_cut()
	{
		myEditor.focus();
		myEditor.document.execCommand('Cut', false, null); 
	}
	function ak_inserthorizontalrule()
	{
		myEditor.focus();
		myEditor.document.execCommand('InsertHorizontalRule', false, null); 
	}
	function ak_saveas()
	{
		myEditor.focus();
		myEditor.document.execCommand('SaveAs', true, "Untitled"); 
	}
	function ak_indent()
	{
		myEditor.focus();
		myEditor.document.execCommand('Indent', false, null); 
	}
	function ak_outdent()
	{
		myEditor.focus();
		myEditor.document.execCommand('Outdent', false, null); 
	}
	
	function ak_insertunorderedlist()
	{
		myEditor.focus();
		document.getElementById('bn_ak_insertorderedlist').className='btn';
		myEditor.document.execCommand('insertUnorderedList', false, null); 
	}
	
	function ak_insertorderedlist()
	{
		myEditor.focus();
		document.getElementById('bn_ak_insertunorderedlist').className='btn';
		myEditor.document.execCommand('insertOrderedList', false, null); 
	}
	
	function ak_justifyleft()
	{
		myEditor.focus();
		document.getElementById('bn_ak_justifyright').className='btn';
		document.getElementById('bn_ak_justifycenter').className='btn';
		document.getElementById('bn_ak_justifyfull').className='btn';
		document.getElementById('bn_ak_justifyfull').disabled=false;
		document.getElementById('bn_ak_justifyright').disabled=false;
		document.getElementById('bn_ak_justifycenter').disabled=false;
		document.getElementById('bn_ak_justifyleft').disabled=true;
		myEditor.document.execCommand('justifyLeft', false, null); 
	}
	
	function ak_justifycenter()
	{
		myEditor.focus();
		document.getElementById('bn_ak_justifyright').className='btn';
		document.getElementById('bn_ak_justifyleft').className='btn';
		document.getElementById('bn_ak_justifyfull').className='btn';
		document.getElementById('bn_ak_justifyfull').disabled=false;
		document.getElementById('bn_ak_justifyright').disabled=false;
		document.getElementById('bn_ak_justifycenter').disabled=true;
		document.getElementById('bn_ak_justifyleft').disabled=false;
		myEditor.document.execCommand('justifyCenter', false, null); 
	}
	
	function ak_justifyright()
	{
		myEditor.focus();
		document.getElementById('bn_ak_justifyleft').className='btn';
		document.getElementById('bn_ak_justifycenter').className='btn';
		document.getElementById('bn_ak_justifyfull').className='btn';
		document.getElementById('bn_ak_justifyfull').disabled=false;
		document.getElementById('bn_ak_justifyright').disabled=true;
		document.getElementById('bn_ak_justifycenter').disabled=false;
		document.getElementById('bn_ak_justifyleft').disabled=false;
		myEditor.document.execCommand('justifyRight', false, null); 
	}
	
	function ak_justifyfull()
	{
		myEditor.focus();
		document.getElementById('bn_ak_justifyleft').className='btn';
		document.getElementById('bn_ak_justifycenter').className='btn';
		document.getElementById('bn_ak_justifyright').className='btn';
		document.getElementById('bn_ak_justifyfull').disabled=true;
		document.getElementById('bn_ak_justifyright').disabled=false;
		document.getElementById('bn_ak_justifycenter').disabled=false;
		document.getElementById('bn_ak_justifyleft').disabled=false;
		myEditor.document.execCommand('JustifyFull', false, null); 
	}
	

	function ak_superscript()
	{
		myEditor.focus();
		if (myEditor.document.queryCommandValue('SuperScript')) {
			myEditor.document.execCommand('RemoveFormat');
		} else {
			myEditor.document.execCommand('SuperScript');
		}
		updatetoolbar();
	}
	
	function ak_subscript()
	{
		myEditor.focus();
		if (myEditor.document.queryCommandValue('SubScript')) {
			myEditor.document.execCommand('RemoveFormat');
		} else {
			myEditor.document.execCommand('SubScript');
		}
		updatetoolbar();
	}
	
	function ak_backcolor()
	{
		var mycolor = showModalDialog(subdirectory + "insertcolors.html", "", "dialogHeight:230px; dialogWidth: 250px; scroll: no; status: no; help: no;");
		myEditor.focus();
		myEditor.document.execCommand('BackColor', true, mycolor); 
	}
	
	function ak_forecolor()
	{
		var mycolor = showModalDialog(subdirectory + "insertcolors.html", "", "dialogHeight:230px; dialogWidth: 250px; scroll: no; status: no; help: no;");
		myEditor.focus();
		myEditor.document.execCommand('ForeColor', true, mycolor); 
	}
	
	function ak_image()
	{
		var myimage = showModalDialog(subdirectory + "insertimage.html", "", "dialogHeight:230px; dialogWidth: 420px; scroll: no; status: no; help: no;");
		if (myimage){		
			ak_inserttags(myimage, "");
		}
	}
	
	function ak_table()
	{
		var mytable = showModalDialog(subdirectory + "inserttable.html", "", "dialogHeight:160px; dialogWidth: 325px; scroll: no; status: no; help: no;");
		if (mytable){	
			ak_inserttags(mytable, "");
		}
	}
	
	function ak_date()
	{
		var myday = showModalDialog(subdirectory + "insertdate.html", "", "dialogHeight:190px; dialogWidth: 215px; scroll: no; status: no; help: no;");
		if (myday){	
			ak_inserttags(myday, "");
		}
	}
	
	function ak_specialchars()
	{
		var mychar = showModalDialog(subdirectory + "insertcharacters.html", "", "dialogHeight:400px; dialogWidth: 340px; scroll: no; status: no; help: no;");
		if (mychar && mychar != ""){		
			ak_inserttags(mychar, "");
		}
	}
	function ak_help()
	{
		showModalDialog(subdirectory + "help.html", "", "dialogHeight:300px; dialogWidth: 400px; scroll: no; status: no; help: no;");
	}
	function ak_info()
	{
		showModalDialog(subdirectory + "aboutus.html", "", "dialogHeight:210px; dialogWidth: 360px; scroll: no; status: no; help: no;");
	}
	
	function ak_inserttags(str1, str2) {
	  	myEditor.focus();
	  	var tr = myEditor.document.selection.createRange();
		if (str2 != ""){tr.pasteHTML(str1 + tr.text + str2);}
		else {tr.pasteHTML(str1);}
		
	  	tr.select();
	  	myEditor.focus();
	}
	
	function ak_changemode()
	{
	 	if (mode == 'html') 
	 	{
	   		innerTmp = myEditor.document.body.innerText;
	   		myEditor.document.body.innerHTML = innerTmp;
	   		mode = 'WYSIWYG' ;
			enablebuttons();
	 	}else{
	   		innerTmp = myEditor.document.body.innerHTML;
	   		myEditor.document.body.innerText = innerTmp;
	   		mode = 'html' ;
			disablebuttons();
	 	}
		var s = myEditor.document.body.createTextRange();
		s.collapse(false);
		s.select();
	}
	
	function m_over(obj){
		if(obj.className=='btn'){obj.className='btnOver'};
	}
	function m_out(obj){
		if(obj.className=='btnOver'){obj.className='btn'};
	}
	function m_click(obj){
		if(obj.className !='btnDown'){obj.className='btnDown';}
		else {obj.className='btn'};
	}
	
	function copycontents() {
		if (txtareaname) {
			document.getElementById(txtareaname).value = myEditor.document.body.innerHTML;
		}
  	}

	function keyHandler() 
	{
		updatetoolbar();
	}
	function externalkeyHandler() 
	{
		copycontents();
	}
	
	function updatetoolbar()
	{
		myEditor.focus();
		//check current text with button's state.
		for (var i=0; i<buttonlist.length; i++) {
			
			if (buttonlist[i] == 'FontSize') {
				if (myEditor.document.queryCommandValue("FontSize")) {
					for (var j = 0; j < document.getElementById('bn_ak_fontsize').options.length; j++ )
					{
						if (document.getElementById('bn_ak_fontsize').options[j].value == ""+myEditor.document.queryCommandValue("FontSize"))
						{
					  		document.getElementById('bn_ak_fontsize').options.selectedIndex = j;
						}
					}
				} else {
					document.getElementById('bn_ak_fontsize').options.selectedIndex = -1;
				}			
			} else if (buttonlist[i] == 'FontName') {
				if (myEditor.document.queryCommandValue("FontName")) {		
					for (var j = 0; j < document.getElementById('bn_ak_fontname').options.length; j++ )
					{
						if (document.getElementById('bn_ak_fontname').options[j].value == ""+myEditor.document.queryCommandValue("FontName"))
						{
					  		document.getElementById('bn_ak_fontname').options.selectedIndex = j;
						}
					}
				} else {
					document.getElementById('bn_ak_fontname').options.selectedIndex = -1;
				}
			} else {
				if (buttonlist[i] != 'Separator' && menuButtons[buttonlist[i]][3]=='1') {
					if (myEditor.document.queryCommandValue(buttonlist[i])) {document.getElementById('bn_ak_'+buttonlist[i].toLowerCase()).className = 'btnDown';}
					else if (document.getElementById('bn_ak_'+buttonlist[i].toLowerCase()).className != 'btnDisabled') {document.getElementById('bn_ak_'+buttonlist[i].toLowerCase()).className = 'btn';}
				}					
			}
		}		
	}
	
	function disablebuttons()
	{
		for (var i=0; i<buttonlist.length;i++){
			if (buttonlist[i] == 'FontName'){
				document.getElementById('bn_ak_fontname').disabled=true;	
			} else if (buttonlist[i] == 'FontSize') {
				document.getElementById('bn_ak_fontsize').disabled=true;
			}else {
				if (buttonlist[i] != 'Separator' && menuButtons[buttonlist[i]][4]=='1') {
					document.getElementById('bn_ak_'+ buttonlist[i].toLowerCase()).className='btnDisabled';
					document.getElementById('bn_ak_'+ buttonlist[i].toLowerCase()).disabled=true;
				}
			}
		}	
	}
	function enablebuttons()
	{			
		for (var i=0; i<buttonlist.length;i++){
			if (buttonlist[i] == 'FontName'){
				document.getElementById('bn_ak_fontname').disabled=false;	
			} else if (buttonlist[i] == 'FontSize') {
				document.getElementById('bn_ak_fontsize').disabled=false;
			}else {
				if (buttonlist[i] != 'Separator' && menuButtons[buttonlist[i]][4]=='1') {
					document.getElementById('bn_ak_'+ buttonlist[i].toLowerCase()).className='btn';
					document.getElementById('bn_ak_'+ buttonlist[i].toLowerCase()).disabled=false;
				}
			}
		}	
		updatetoolbar();
	}