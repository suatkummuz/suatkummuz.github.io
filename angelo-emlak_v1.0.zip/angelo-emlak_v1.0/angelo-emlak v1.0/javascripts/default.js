<!--angelo_js_start
var DHTML = (document.all || document.layers);
function erdal(buyuk){
    if(buyuk==1){
		document.oldu_sana_iki_kelek1.src="images/angelo_menu_1b.gif";
	}
	if(buyuk==2){
		document.oldu_sana_iki_kelek2.src="images/angelo_menu_2b.gif";
	}
	if(buyuk==3){
		document.oldu_sana_iki_kelek3.src="images/angelo_menu_3b.gif";
	}
	if(buyuk==4){
		document.oldu_sana_iki_kelek4.src="images/angelo_menu_4b.gif";
	}
	if(buyuk==5){
		document.oldu_sana_iki_kelek5.src="images/angelo_menu_5b.gif";
	}
	if(buyuk==6){
		document.oldu_sana_iki_kelek6.src="images/angelo_menu_6b.gif";
	}
}
function melek(kuskira){
    if(kuskira==1){
		document.oldu_sana_iki_kelek1.src="images/angelo_menu_1a.gif";
	}
	if(kuskira==2){
		document.oldu_sana_iki_kelek2.src="images/angelo_menu_2a.gif";
	}
	if(kuskira==3){
		document.oldu_sana_iki_kelek3.src="images/angelo_menu_3a.gif";
	}
	if(kuskira==4){
		document.oldu_sana_iki_kelek4.src="images/angelo_menu_4a.gif";
	}
	if(kuskira==5){
		document.oldu_sana_iki_kelek5.src="images/angelo_menu_5a.gif";
	}
	if(kuskira==6){
		document.oldu_sana_iki_kelek6.src="images/angelo_menu_6a.gif";
	}
}
function ap_getObj(name) {
    if (document.sanalecza) {
        return document.aspsitem(name).style;
    }
    else if (document.all) {
        return document.all[name].style;
    }
    else if (document.layers) {
        return document.layers[name];
    }
}
function ap_showWaitMessage(div,flag)  {
    if (!DHTML) return;
    var x = ap_getObj(div);
    x.visibility = (flag) ? 'visible':'hidden'
    if(document.layers) x.left=280/2;
    return true;
}
ap_showWaitMessage('angela', 1); 
//angelo_js_end-->